var searchData=
[
  ['college',['college',['../classcollege.html',1,'']]],
  ['course',['course',['../classcourse.html',1,'']]]
];
