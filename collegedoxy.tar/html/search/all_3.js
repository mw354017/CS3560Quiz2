var searchData=
[
  ['load',['load',['../classcollege.html#ab27de382f28a46e2bd3d82903843d4d9',1,'college']]]
];
