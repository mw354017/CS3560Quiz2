var searchData=
[
  ['save',['save',['../classcollege.html#ae86e11e6643736a60b6df911820c6510',1,'college']]],
  ['set_5fcourse',['set_course',['../classcourse.html#a1fce1a16efb3f07d0da5daca8005e4a6',1,'course']]]
];
